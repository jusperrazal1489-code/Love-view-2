package com.loveview.viewer

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(15, 15, 18))
        }
        val title = TextView(this).apply {
            text = "LOVE VIEW VIEWER"
            textSize = 26f
            setTextColor(Color.RED)
            gravity = Gravity.CENTER
        }
        val status = TextView(this).apply {
            text = "Not connected\nPairing and live streaming service are not configured yet."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val connect = Button(this).apply {
            text = "PAIR / CONNECT"
            setOnClickListener { status.text = "No sender connected. Configure secure pairing and streaming server first." }
        }
        val disconnect = Button(this).apply {
            text = "DISCONNECT"
            setOnClickListener { status.text = "Disconnected" }
        }
        root.addView(title); root.addView(status); root.addView(connect); root.addView(disconnect)
        setContentView(root)
    }
}
