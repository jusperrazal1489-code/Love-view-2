package com.loveview.sender

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCode = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(15, 15, 18))
        }
        val title = TextView(this).apply {
            text = "LOVE VIEW SENDER"
            textSize = 26f
            setTextColor(Color.RED)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Camera and microphone are OFF"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "AUTHORIZE CAMERA & MIC"
            setOnClickListener { requestMediaPermissions() }
        }
        val stop = Button(this).apply {
            text = "STOP / TURN OFF"
            setOnClickListener { status.text = "Camera and microphone are OFF" }
        }
        root.addView(title); root.addView(status); root.addView(start); root.addView(stop)
        setContentView(root)
    }

    private fun requestMediaPermissions() {
        val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), requestCode)
        } else {
            status.text = "Permissions granted. Streaming is not configured yet."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            status.text = if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
                "Permissions granted. Streaming is not configured yet."
            else "Permission denied. Camera and microphone remain OFF."
        }
    }
}
