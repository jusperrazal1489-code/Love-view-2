# LOVE VIEW Android build starter

This repository starter contains two Android app modules:
- `sender`: permission-based local camera/microphone preview and explicit start/stop controls.
- `viewer`: viewer UI shell and pairing placeholder.

**Important:** This starter does NOT yet stream live video/audio between phones. Remote streaming requires a WebRTC signaling service (and usually STUN/TURN configuration), authenticated pairing, and testing. Do not treat the placeholder pairing screen as a working connection.

## Build
GitHub Actions workflow `.github/workflows/build-apks.yml` builds debug APKs on pushes to `main` or manual dispatch. Download them from the workflow run's **Artifacts** section.

## Open locally
Open this folder in Android Studio. Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, compile SDK 35.
